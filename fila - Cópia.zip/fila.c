#include <stdio.h>
#include <stdlib.h>

#include "fila.h"

struct filas {
    int cabeca;
    int cauda;
    int tamanho;
    int tamanho_max;
    int *dados;
};

//cria uma nova fila
fila_t* cria_fila(int tamanho)
{
    fila_t *p = NULL;

    //aloca memória
    p = (fila_t*)malloc(sizeof(fila_t));


    //variaveis de controle
    p->cabeca = 0;
    p->cauda = tamanho-1;
    p->tamanho = 0;
    p->tamanho_max = tamanho;

    p->dados = (int*) malloc(sizeof(int) * tamanho);

    return p;
}

//libera memoria
void libera_fila(fila_t* fila)
{
    fila_t *p = fila;

    if (p == NULL)
    {
        fprintf(stderr, "Erro desalocando memoria da fila, ponteiro invalido!");
        exit(EXIT_FAILURE);
    }


    free(p->dados);
    free(p);
}


void enqueue(int x, fila_t* fila)
{

}

int dequeue(fila_t* fila)
{


    return 0;
}

//------------------
//funcoes adicionais
