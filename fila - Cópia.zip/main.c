#include <stdio.h>
#include <stdlib.h>

#include "fila.h"


int main()
{
    fila_t* fila = NULL;

    fila = cria_fila(10);


    //queue(fila, 10);
    //queue(fila, 18);
    //queue(fila,9990);


    //x = dequeue();
    //printf("%d\",x);
    //x = dequeue();
    //x = dequeue();

    //(...)

    libera_fila(fila);

    return 0;
}
